module.exports={
    OSCARNEWMAN_ADMIN_TOKEN:"securityatitsbest",
    MYSQL_HOST: "b12bt2g4xg6kspzwhr0j-mysql.services.clever-cloud.com",
    DB_NAME: "b12bt2g4xg6kspzwhr0j",
    DB_PASSWORD: "jALOHYnIYe7ue3YjdEW0",
    DB_PORT: "3306",
    DB_USER : "uquoagjuxuboztht",
    DIALECT : "mysql"
}