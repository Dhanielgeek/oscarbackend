const cloudinary = require("cloudinary").v2


cloudinary.config({
cloud_name: "dmudvthm5",
api_key: "355539672399792",
api_secret: "D7KBYBiYaVcGadRjJ4mU--FzvJk"
})

module.exports=cloudinary